
rm(list=ls(all=TRUE))
working_dir="/home/tparamas/INSOFE_CPEE/CSE7203c/TimeSeriesRCode"
setwd(working_dir)

kings<-scan("kings.dat",skip=3)
summary(kings)
str(kings)
kingstimeseries <- ts(kings)
kingstimeseries
plot(kingstimeseries)



#For monthly time series data, 
#you set frequency=12, 
#while for quarterly time series data, 
#you set frequency=4

#You can also specify the first year that the data was collected, 
#and the first interval in that year by using the 'start' parameter in the ts() function.
# For example, if the first data 
#point corresponds to the second quarter of 1986, you would set 
#start=c(1986,2)

#data set of the number of births per month in New York city, from January 1946 to December 1959

births <- scan("nybirths.dat")
births

birthstimeseries <- ts(births,frequency=12,start=c(1946,1))
birthstimeseries

#Plotting
plot.ts(kingstimeseries)
plot(birthstimeseries)

#Decomposition
Kingstimeseriescom <- decompose(kingstimeseries)
birthstimeseriescomponents <-  decompose(birthstimeseries)

plot(birthstimeseriescomponents)
birthstimeseriescomponents$seasonal
birthstimeseriescomponents$trend
# To find out type of time series
birthstimeseriescomponents$type


# seasonality additive - when the seasonal trends is same size of spike from begin to end of the chart
# seasonality multiplicative -  when the seasonal trends has fluctuations 

# Reducing seasonal component from TS.

#Seasonally adjusting.

# birthTS has both trends and sesonal comp. removing sesonal comp.
# It is usually done when wanting to analyse the trend of a time series 
#independently of the seasonal components.
birthstimeseriesSeasonally <-  birthstimeseries - birthstimeseriescomponents$seasonal
birthstimeseriesSeasonally_removed_only_rnd_comp <- decompose(birthstimeseriesSeasonally)
plot(birthstimeseriesSeasonally_removed_only_rnd_comp)

par(mfrow=c(1,2))
plot(birthstimeseriescomponents$seasonal)
plot(birthstimeseriesSeasonally)


#ACF and PACF of real world data

par(mfrow=c(1,3))
plot.ts(kingstimeseries)
acf(kingstimeseries, lag.max=20)
pacf(kingstimeseries, lag.max=20)

plot(birthstimeseries)
acf(birthstimeseries)
pacf(birthstimeseries, lag.max=20)

ma <- birthstimeseriescomponents$random
trend <- birthstimeseriescomponents$trend
seas <- birthstimeseriescomponents$seasonal

par(mfrow=c(2,2))
plot(birthstimeseries)
plot(trend)
plot(seas)
plot(ma)

#Regression on time

par(mfrow=c(1,1))
births <- data.frame(births)
births$time <- seq(1:168)
edit(births)
plot(births$births, type="l")
lm1 <- lm(births$births ~ births$time)
lm2 <- lm(births$births ~ 
            poly(births$time, 2, raw=TRUE))
lm3 <- lm(births$births ~ 
            poly(births$time, 3, raw=TRUE))

points(births$time, predict(lm1), 
       type="l", col="red", lwd=2)
points(births$time, predict(lm2), 
       type="l", col="green", lwd=2)
points(births$time, predict(lm3), 
       type="l", col="blue", lwd=2)

births$seasonal <- as.factor(rep(c(1:12),14))
edit(births)

lm1s <- lm(births ~ ., data=births)
plot(lm1)
lm2s <- lm(births ~ poly(time, 2, raw=TRUE)+
            seasonal, data=births)
lm3s <- lm(births ~ poly(time, 3, raw=TRUE)+
             seasonal, data=births)

plot(births$births, type="l")
points(births$time, predict(lm1s), 
       type="l", col="red", lwd=2)
points(births$time, predict(lm2s), 
       type="l", col="blue", lwd=2)

plot(births$births, type="l")
points(births$time, predict(lm3s), 
       type="l", col="green", lwd=2)

#Another crude approach

births$mae <- births$births/predict(lm1)
births$month <- rep(seq(1:12),14)
edit(births)
head(births)

seasonal <- tapply(births$mae, 
                   births$month, mean)
seasonal

birthspr <- predict(lm1)*rep(seasonal,14)

plot(births$births, type="l")
points(births$time, birthspr, 
       type="l", col="red", lwd=2)


#Moving averages

library(TTR)

par(mfrow=c(1,1))
kingstimeseries
plot(kingstimeseries)

smaKings <- SMA(kingstimeseries, n=4)
smaKings

wmaKings <- WMA(kingstimeseries, n=4)
wmaKings

emaKings <- EMA(kingstimeseries, n=4)
emaKings

par(mfrow=c(1,1))
plot(kingstimeseries, type="l", col="red")
lines(smaKings, col="green")
lines(wmaKings, col="blue")
lines(emaKings)

errorSMA <- mean(abs(kingstimeseries[4:24]-smaKings[4:24]))
errorWMA <- mean(abs(kingstimeseries[4:24]-wmaKings[4:24]))
errorEMA <- mean(abs(kingstimeseries[4:24]-emaKings[4:24]))

#Effect of K

kingstimeseriesSMA3 <- 
  SMA(kingstimeseries,n=3)

kingstimeseriesSMA8 <- SMA(kingstimeseries,
                           n=8)

par(mfrow = c(1, 2))
plot.ts(kingstimeseriesSMA3)
plot.ts(kingstimeseriesSMA8)

par(mfrow = c(1, 1))

#Moving average without trend and seasonality, ie a randomn process
plot(birthstimeseries)

#ARIMA

plot(birthstimeseries)
birthstimeseriesdiff1 <- diff(birthstimeseries, 
       differences=1)
plot.ts(birthstimeseriesdiff1)

birthstimeseriesdiff2 <- diff(birthstimeseries, 
       differences=2)
plot.ts(birthstimeseriesdiff2)


#Plotting acf and pacf plots for differenced time series once

par(mfrow=c(1,2))
acf(birthstimeseries)
pacf(birthstimeseries, lag.max=20)

acf(birthstimeseriesdiff1, lag.max=20)
pacf(birthstimeseriesdiff1, lag.max=20)

acf(birthstimeseriesdiff2, lag.max=20)
pacf(birthstimeseriesdiff2, lag.max=20)

#Auto.Arima
library(forecast)
auto.arima(birthstimeseries)

#Parsimonious models(Predicting)

birthstimeseriesA <- auto.arima(birthstimeseries,ic='aic')
birthstimeseriesA
birthstimeseriesforecasts <- forecast.Arima(birthstimeseriesA, h=5)
plot.forecast(birthstimeseriesforecasts)
 

